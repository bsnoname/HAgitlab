external_url 'https://gittest.saobang.vn'

#prometheus['enable'] = false
#mailroom['enable'] = false
#alertmanager['enable'] = false
#gitlab_exporter['enable'] = false
#gitlab_pages['enable'] = false
#grafana['enable'] = false
#node_exporter['enable'] = false
#postgres_exporter['enable'] = false
#redis_exporter['enable'] = false
#puma['enable'] = true

nginx['redirect_http_to_https'] = true
nginx['listen_port'] = 443
letsencrypt['enable'] = false
nginx['ssl_certificate'] = "/etc/ssl/certs/gitlab/gittest.saobang.vn.crt"
nginx['ssl_certificate_key'] = "/etc/ssl/certs/gitlab/gittest.saobang.vn.key"
nginx['ssl_protocols'] = "TLSv1.1 TLSv1.2"

###############Config postgresql ###################
postgresql['enable'] = false;
gitlab_rails['db_host'] = "10.0.8.18";
gitlab_rails['db_adapter'] = 'postgresql';
gitlab_rails['db_encoding'] = 'utf8';
gitlab_rails['db_username'] = 'gitlab';
gitlab_rails['db_password'] = 'gitlab';
gitlab_rails['db_port'] = '5432';
gitlab_rails['db_database'] = 'gitlabhq_production';

###################Config Redis#####################
redis['enable'] = false;
gitlab_rails['redis_host'] = '10.0.8.18';
gitlab_rails['redis_port'] = 6378;
gitlab_rails['redis_password'] = 'Next123Tech@';


gitlab_rails['trusted_proxies'] = ['0.0.0.0/16']
gitlab_rails['time_zone'] = 'Asia/Ho_Chi_Minh'
gitlab_rails['gitlab_shell_ssh_port'] = 222
#gitlab_rails['auto_migrate'] = false
